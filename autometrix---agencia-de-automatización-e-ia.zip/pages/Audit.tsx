
import React, { useState } from 'react';
import { Link } from 'react-router-dom';

export const Audit: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    nombre: '',
    empresa: '',
    sector: '',
    empleados: '',
    objetivo: [] as string[],
    problema: '',
    email: '',
    whatsapp: '',
    horario: 'mañana',
    rgpd: false
  });

  const handleCheckbox = (value: string) => {
    setFormData(prev => ({
      ...prev,
      objetivo: prev.objetivo.includes(value) 
        ? prev.objetivo.filter(v => v !== value) 
        : [...prev.objetivo, value]
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.rgpd) {
      setSubmitted(true);
      window.scrollTo(0, 0);
    } else {
      alert("Debes aceptar la política de privacidad.");
    }
  };

  if (submitted) {
    return (
      <div className="min-h-[80vh] flex items-center justify-center bg-slate-50 px-4">
        <div className="max-w-xl w-full bg-white rounded-[2rem] p-10 text-center shadow-xl border border-slate-100">
          <div className="w-20 h-20 bg-green-100 text-green-600 flex items-center justify-center rounded-full mx-auto mb-8 text-4xl">✓</div>
          <h1 className="text-3xl font-display font-bold text-slate-900 mb-4">¡Solicitud recibida!</h1>
          <p className="text-slate-500 mb-10 leading-relaxed">
            Te contactaremos en menos de 24h laborables para agendar tu sesión de 15-20 min. Mientras tanto, puedes echar un vistazo a lo que hemos hecho para otros clientes.
          </p>
          <Link to="/casos" className="inline-block bg-violet-600 text-white px-8 py-4 rounded-xl font-bold hover:bg-violet-700 transition-all">
            Ver casos y demos
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="py-20 bg-slate-50">
      <div className="container mx-auto px-4 md:px-6 grid lg:grid-cols-2 gap-16 items-start">
        <div>
          <span className="bg-violet-100 text-violet-700 text-xs font-bold px-3 py-1 rounded-full mb-6 inline-block">SESIÓN ESTRATÉGICA</span>
          <h1 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mb-8 leading-tight">
            Auditoría gratuita de IA y automatización (15–20 min)
          </h1>
          <p className="text-lg text-slate-500 mb-12">
            Sal de dudas. En 20 minutos analizaremos tu negocio y te daremos claridad total sobre cómo la tecnología puede trabajar para ti.
          </p>
          
          <div className="space-y-8">
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-white rounded-xl shadow-sm border border-slate-100 flex items-center justify-center shrink-0">1</div>
              <div>
                <h3 className="font-bold text-slate-900">Identificamos los 3 procesos con mayor ROI</h3>
                <p className="text-sm text-slate-500">Buscamos lo que te ahorra más tiempo y dinero hoy mismo.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-white rounded-xl shadow-sm border border-slate-100 flex items-center justify-center shrink-0">2</div>
              <div>
                <h3 className="font-bold text-slate-900">Estimación de ahorro</h3>
                <p className="text-sm text-slate-500">Cifras realistas de cuánto tiempo recuperará tu equipo.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-12 h-12 bg-white rounded-xl shadow-sm border border-slate-100 flex items-center justify-center shrink-0">3</div>
              <div>
                <h3 className="font-bold text-slate-900">Roadmap 7-14 días</h3>
                <p className="text-sm text-slate-500">Un plan de acción ejecutable de inmediato.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-8 md:p-12 rounded-[2rem] shadow-xl border border-slate-100">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Nombre y apellidos</label>
                <input required type="text" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all" />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Empresa</label>
                <input required type="text" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all" />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Sector</label>
                <select className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all">
                  <option>Salud/Clínica</option>
                  <option>E-commerce/Retail</option>
                  <option>Servicios Profesionales</option>
                  <option>Hostelería</option>
                  <option>Educación</option>
                  <option>Otro</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Nº empleados</label>
                <select className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all">
                  <option>1-5</option>
                  <option>6-20</option>
                  <option>21-50</option>
                  <option>50+</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-4">Objetivo principal (puedes marcar varios)</label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {['Ventas', 'Atención', 'Operaciones', 'Facturas', 'Citas', 'Métricas'].map(obj => (
                  <label key={obj} className="flex items-center gap-2 text-sm cursor-pointer p-2 rounded-lg hover:bg-slate-50 transition-colors">
                    <input type="checkbox" onChange={() => handleCheckbox(obj)} className="w-4 h-4 rounded text-violet-600 focus:ring-violet-500" />
                    {obj}
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Descripción del problema</label>
              <textarea rows={3} placeholder="¿Qué proceso te quita más tiempo?" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all"></textarea>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Email corporativo</label>
                <input required type="email" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all" />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Teléfono / WhatsApp</label>
                <input required type="tel" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 transition-all" />
              </div>
            </div>

            <label className="flex gap-3 cursor-pointer">
              <input required type="checkbox" checked={formData.rgpd} onChange={(e) => setFormData({...formData, rgpd: e.target.checked})} className="mt-1 w-4 h-4 rounded text-violet-600 focus:ring-violet-500" />
              <span className="text-xs text-slate-500 leading-relaxed">
                Acepto la <Link to="/politica-privacidad" className="text-violet-600 underline">política de privacidad</Link>. Los datos serán tratados por Autometrix para gestionar tu solicitud de auditoría.
              </span>
            </label>

            <button type="submit" className="w-full bg-violet-600 hover:bg-violet-700 text-white py-5 rounded-2xl font-bold text-lg shadow-xl shadow-violet-200 transition-all transform hover:scale-[1.02]">
              Enviar solicitud gratuita
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
