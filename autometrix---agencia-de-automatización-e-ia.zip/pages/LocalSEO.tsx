
import React from 'react';
import { Link } from 'react-router-dom';
import { SERVICES } from '../constants';

export const LocalSEO: React.FC = () => {
  return (
    <div className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-4xl mx-auto mb-20 text-center">
          <h1 className="text-4xl md:text-6xl font-display font-bold text-slate-900 mb-8">
            Agencia de IA en <span className="text-violet-600">Albacete</span>: automatización y chatbots
          </h1>
          <p className="text-lg text-slate-500 leading-relaxed">
            Ayudamos a las empresas de Albacete y Castilla-La Mancha a liderar la revolución tecnológica. No somos una agencia remota más; somos tus vecinos y entendemos el tejido empresarial local.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-20 items-center mb-32">
          <div>
            <h2 className="text-3xl font-display font-bold text-slate-900 mb-6">¿Por qué elegir una agencia local de IA?</h2>
            <div className="space-y-6">
              {[
                { title: 'Cercanía Real', desc: 'Podemos reunirnos en tu oficina en Albacete para entender tus procesos en vivo.' },
                { title: 'Soporte Directo', desc: 'Sin tickets infinitos ni diferencias horarias. Estamos aquí.' },
                { title: 'Adaptación al Sector', desc: 'Conocemos el mercado manchego, desde la industria hasta la hostelería.' }
              ].map((item, i) => (
                <div key={i} className="flex gap-4">
                  <div className="w-8 h-8 rounded-full bg-violet-100 text-violet-600 flex items-center justify-center font-bold text-sm shrink-0">{i+1}</div>
                  <div>
                    <h4 className="font-bold text-slate-900">{item.title}</h4>
                    <p className="text-sm text-slate-500">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="bg-slate-50 rounded-[3rem] p-10 relative">
             <div className="aspect-square bg-white rounded-2xl shadow-xl flex items-center justify-center text-6xl">📍</div>
             <div className="absolute -bottom-6 -right-6 bg-violet-600 text-white p-6 rounded-2xl shadow-lg font-bold">
               Orgullosos de Albacete
             </div>
          </div>
        </div>

        <div className="bg-slate-50 rounded-[3rem] p-12 md:p-20">
          <h2 className="text-3xl font-display font-bold text-slate-900 mb-12 text-center">Servicios destacados para empresas locales</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {SERVICES.slice(0, 3).map(s => (
              <div key={s.id} className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
                <h3 className="font-bold text-xl mb-4">{s.title}</h3>
                <p className="text-sm text-slate-500 mb-6">{s.description}</p>
                <Link to={`/servicios/${s.slug}`} className="text-violet-600 font-bold text-sm hover:underline">Ver detalles</Link>
              </div>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link to="/auditoria-gratis" className="bg-violet-600 text-white px-8 py-4 rounded-xl font-bold hover:bg-violet-700 transition-all shadow-lg shadow-violet-200">
              Solicitar visita / Auditoría
            </Link>
          </div>
        </div>

        {/* Schema JSON-LD specifically for this page */}
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              "name": "Autometrix",
              "description": "Agencia de Inteligencia Artificial y Automatización en Albacete.",
              "areaServed": {
                "@type": "AdministrativeArea",
                "name": "Albacete"
              },
              "address": {
                "@type": "PostalAddress",
                "addressLocality": "Albacete",
                "addressRegion": "Castilla-La Mancha",
                "addressCountry": "ES"
              },
              "telephone": ["+34648465788", "+34657405972"],
              "email": "infoai@autometrixai.com",
              "url": "https://autometrix.ai/agencia-ia-albacete"
            }
          `}
        </script>
      </div>
    </div>
  );
};
