
import React from 'react';
import { Link } from 'react-router-dom';
import { SERVICES, SECTORS } from '../constants';

const Hero: React.FC = () => (
  <section className="relative overflow-hidden pt-20 pb-32 bg-glow-purple">
    <div className="container mx-auto px-4 md:px-6 flex flex-col lg:flex-row items-center gap-12">
      <div className="lg:w-3/5 text-center lg:text-left">
        <span className="inline-block bg-violet-100 text-violet-700 text-xs font-bold uppercase tracking-widest px-3 py-1 rounded-full mb-6">
          Agencia de IA y Automatización
        </span>
        <h1 className="text-4xl md:text-6xl font-display font-bold text-slate-900 leading-[1.1] mb-8">
          Integramos IA en tu negocio para <span className="text-violet-600">ahorrar tiempo</span>, reducir costes y vender más.
        </h1>
        <p className="text-lg text-slate-600 mb-10 max-w-2xl leading-relaxed">
          Automatización de procesos, chatbots de WhatsApp y voz, dashboards y desarrollo de SaaS. Somos tu socio tecnológico de IA: implementamos hoy y optimizamos cada vez que la IA evoluciona.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
          <Link to="/auditoria-gratis" className="bg-violet-600 hover:bg-violet-700 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-xl shadow-violet-200 transition-all transform hover:-translate-y-1">
            Pedir auditoría gratis
          </Link>
          <Link to="/casos" className="bg-white border-2 border-slate-100 hover:border-violet-200 text-slate-700 px-8 py-4 rounded-xl font-bold text-lg transition-all">
            Ver casos y demos
          </Link>
        </div>
      </div>
      <div className="lg:w-2/5 relative">
        <div className="relative z-10 bg-white/40 backdrop-blur-xl border border-white/60 p-6 rounded-3xl shadow-2xl animate-float">
          <div className="space-y-4">
            <div className="flex items-center gap-4 bg-white p-4 rounded-2xl shadow-sm border border-slate-50">
              <div className="w-10 h-10 bg-green-100 text-green-600 flex items-center justify-center rounded-full">↓</div>
              <div>
                <p className="text-xs text-slate-400 font-medium">No-shows</p>
                <p className="font-bold text-slate-900">-35% en 30 días</p>
              </div>
            </div>
            <div className="flex items-center gap-4 bg-white p-4 rounded-2xl shadow-sm border border-slate-50">
              <div className="w-10 h-10 bg-violet-100 text-violet-600 flex items-center justify-center rounded-full">⏱</div>
              <div>
                <p className="text-xs text-slate-400 font-medium">Administración</p>
                <p className="font-bold text-slate-900">-20h / semana</p>
              </div>
            </div>
            <div className="flex items-center gap-4 bg-white p-4 rounded-2xl shadow-sm border border-slate-50">
              <div className="w-10 h-10 bg-blue-100 text-blue-600 flex items-center justify-center rounded-full">🚀</div>
              <div>
                <p className="text-xs text-slate-400 font-medium">Atención 24/7</p>
                <p className="font-bold text-slate-900">Activo e inteligente</p>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute -top-10 -right-10 w-64 h-64 bg-violet-400/10 blur-[100px] rounded-full"></div>
      </div>
    </div>
  </section>
);

const Pillars: React.FC = () => (
  <section className="py-24 bg-white">
    <div className="container mx-auto px-4 md:px-6">
      <div className="text-center mb-16">
        <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-4">¿Qué hacemos por tu empresa?</h2>
        <p className="text-slate-500">Transformamos operaciones tradicionales en sistemas de alto rendimiento.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        {[
          { 
            title: 'Automatización + Integraciones', 
            desc: 'Conectamos n8n, Google Workspace y CRMs para que tus datos fluyan sin errores.', 
            icon: '⚡' 
          },
          { 
            title: 'IA Aplicada al Negocio', 
            desc: 'Voz, WhatsApp, Agentes RAG y procesamiento inteligente de información.', 
            icon: '🧠' 
          },
          { 
            title: 'Software a Medida', 
            desc: 'Desarrollo de SaaS internos, web corporativas y landings optimizadas para conversión.', 
            icon: '💻' 
          },
        ].map((p, idx) => (
          <div key={idx} className="p-10 rounded-3xl bg-slate-50 border border-slate-100 transition-all hover:bg-white hover:shadow-xl hover:border-violet-100 group">
            <div className="text-4xl mb-6 group-hover:scale-110 transition-transform inline-block">{p.icon}</div>
            <h3 className="text-xl font-bold mb-4 text-slate-900">{p.title}</h3>
            <p className="text-slate-500 leading-relaxed">{p.desc}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const ServiceGrid: React.FC = () => (
  <section className="py-24 bg-slate-50">
    <div className="container mx-auto px-4 md:px-6">
      <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-4">
        <div>
          <h2 className="text-3xl md:text-4xl font-display font-bold text-slate-900 mb-4">Servicios especializados</h2>
          <p className="text-slate-500">Soluciones técnicas para retos de negocio actuales.</p>
        </div>
        <Link to="/servicios" className="text-violet-600 font-bold hover:underline">Ver todos los servicios →</Link>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {SERVICES.map((s) => (
          <Link key={s.id} to={`/servicios/${s.slug}`} className="p-8 bg-white rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all purple-glow-hover flex flex-col justify-between">
            <div>
              <div className="text-3xl mb-4">{s.icon}</div>
              <h3 className="text-lg font-bold mb-2 text-slate-900">{s.title}</h3>
              <p className="text-sm text-slate-500 mb-6">{s.description}</p>
            </div>
            <span className="text-violet-600 text-sm font-bold">Saber más</span>
          </Link>
        ))}
      </div>
    </div>
  </section>
);

const CTASection: React.FC = () => (
  <section className="py-24 bg-white">
    <div className="container mx-auto px-4 md:px-6">
      <div className="bg-violet-600 rounded-[3rem] p-10 md:p-20 text-center text-white relative overflow-hidden shadow-2xl shadow-violet-300">
        <div className="relative z-10 max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-5xl font-display font-bold mb-6">¿Preparado para escalar?</h2>
          <p className="text-lg text-violet-100 mb-10">Te decimos en 48h dónde pierdes dinero y cómo arreglarlo con IA de forma profesional y escalable.</p>
          <Link to="/auditoria-gratis" className="inline-block bg-white text-violet-600 hover:bg-violet-50 px-10 py-5 rounded-2xl font-bold text-xl transition-all shadow-lg">
            Solicitar Auditoría Gratuita
          </Link>
        </div>
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-violet-400/20 rounded-full translate-y-1/2 -translate-x-1/2 blur-3xl"></div>
      </div>
    </div>
  </section>
);

export const Home: React.FC = () => {
  return (
    <>
      <Hero />
      <Pillars />
      <ServiceGrid />
      <CTASection />
    </>
  );
};
