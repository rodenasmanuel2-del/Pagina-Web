
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { NAV_LINKS } from '../constants';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}>
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">A</div>
          <span className="font-display font-bold text-xl tracking-tight text-slate-900">Autometrix</span>
        </Link>
        
        <nav className="hidden lg:flex items-center gap-8">
          {NAV_LINKS.map((link) => (
            <Link 
              key={link.path} 
              to={link.path} 
              className={`text-sm font-medium transition-colors hover:text-violet-600 ${location.pathname === link.path ? 'text-violet-600' : 'text-slate-600'}`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <Link 
          to="/auditoria-gratis" 
          className="bg-violet-600 hover:bg-violet-700 text-white px-6 py-2.5 rounded-full text-sm font-semibold transition-all shadow-lg shadow-violet-200"
        >
          Auditoría gratis
        </Link>
      </div>
    </header>
  );
};

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-50 border-t border-slate-100 pt-20 pb-10">
      <div className="container mx-auto px-4 md:px-6 grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
        <div className="col-span-1 md:col-span-1">
          <Link to="/" className="flex items-center gap-2 mb-6">
            <div className="w-8 h-8 bg-violet-600 rounded-lg flex items-center justify-center text-white font-bold text-xl">A</div>
            <span className="font-display font-bold text-xl tracking-tight">Autometrix</span>
          </Link>
          <p className="text-slate-500 text-sm leading-relaxed">
            Tu socio estratégico en automatización e Inteligencia Artificial en Albacete. Maximizamos el ROI de tu negocio implementando tecnología que trabaja por ti.
          </p>
        </div>
        <div>
          <h4 className="font-display font-bold mb-6 text-slate-900">Servicios</h4>
          <ul className="space-y-4 text-sm text-slate-500">
            <li><Link to="/servicios/automatizacion-procesos-n8n" className="hover:text-violet-600">Automatización n8n</Link></li>
            <li><Link to="/servicios/chatbots-whatsapp-empresas" className="hover:text-violet-600">Chatbots WhatsApp</Link></li>
            <li><Link to="/servicios/chatbot-voz-empresas" className="hover:text-violet-600">IA de Voz</Link></li>
            <li><Link to="/servicios/desarrollo-saas-empresas" className="hover:text-violet-600">Desarrollo SaaS</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display font-bold mb-6 text-slate-900">Empresa</h4>
          <ul className="space-y-4 text-sm text-slate-500">
            <li><Link to="/sobre-nosotros" className="hover:text-violet-600">Sobre nosotros</Link></li>
            <li><Link to="/proceso" className="hover:text-violet-600">Nuestro proceso</Link></li>
            <li><Link to="/casos" className="hover:text-violet-600">Casos de éxito</Link></li>
            <li><Link to="/agencia-ia-albacete" className="hover:text-violet-600">IA en Albacete</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-display font-bold mb-6 text-slate-900">Contacto</h4>
          <ul className="space-y-4 text-sm text-slate-500">
            <li className="flex items-start gap-2"><span>📍</span> Albacete, España</li>
            <li className="flex items-start gap-2"><span>✉️</span> <a href="mailto:infoai@autometrixai.com" className="hover:text-violet-600">infoai@autometrixai.com</a></li>
            <li className="flex items-start gap-2">
              <span>📞</span> 
              <div className="flex flex-col gap-1">
                <a href="tel:+34648465788" className="hover:text-violet-600">648 465 788</a>
                <a href="tel:+34657405972" className="hover:text-violet-600">657 405 972</a>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <div className="container mx-auto px-4 md:px-6 border-t border-slate-200 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-400">
        <p>© 2024 Autometrix. Todos los derechos reservados.</p>
        <div className="flex gap-6">
          <Link to="/aviso-legal" className="hover:text-violet-600">Aviso Legal</Link>
          <Link to="/politica-privacidad" className="hover:text-violet-600">Privacidad</Link>
          <Link to="/politica-cookies" className="hover:text-violet-600">Cookies</Link>
          <Link to="/accesibilidad" className="hover:text-violet-600">Accesibilidad</Link>
        </div>
      </div>
    </footer>
  );
};

const CookieBanner: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem('cookie-consent');
    if (!consent) setIsVisible(true);
  }, []);

  const handleAction = (type: 'all' | 'essential' | 'custom') => {
    localStorage.setItem('cookie-consent', type);
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 w-full z-[60] p-4">
      <div className="container mx-auto max-w-4xl bg-white border border-slate-200 shadow-2xl rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-center gap-6">
        <div className="flex-1">
          <h5 className="font-bold text-slate-900 mb-2">Respetamos tu privacidad</h5>
          <p className="text-sm text-slate-500 leading-relaxed">
            Utilizamos cookies propias y de terceros para mejorar tu experiencia, analizar nuestro tráfico y mostrarte contenido relevante. Puedes aceptar todas o configurar tus preferencias.
          </p>
        </div>
        <div className="flex flex-wrap gap-3 shrink-0">
          <button onClick={() => handleAction('custom')} className="text-sm font-medium text-slate-600 px-4 py-2 hover:bg-slate-50 rounded-lg">Configurar</button>
          <button onClick={() => handleAction('essential')} className="text-sm font-medium text-slate-600 px-4 py-2 hover:bg-slate-50 border border-slate-200 rounded-lg">Solo esenciales</button>
          <button onClick={() => handleAction('all')} className="text-sm font-bold text-white bg-violet-600 px-6 py-2 rounded-lg hover:bg-violet-700">Aceptar todas</button>
        </div>
      </div>
    </div>
  );
};

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col pt-20">
      <Header />
      <main className="flex-grow">{children}</main>
      <Footer />
      <CookieBanner />
    </div>
  );
};
