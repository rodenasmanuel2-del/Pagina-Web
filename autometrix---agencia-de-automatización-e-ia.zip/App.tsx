
import React from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Audit } from './pages/Audit';
import { LocalSEO } from './pages/LocalSEO';

// Simplified pages for build - in real world these would be in separate files
const PlaceholderPage: React.FC<{ title: string }> = ({ title }) => (
  <div className="py-32 text-center container mx-auto px-4">
    <h1 className="text-4xl font-display font-bold mb-4">{title}</h1>
    <p className="text-slate-500">Esta sección está siendo optimizada por nuestra IA. Vuelve pronto.</p>
    <div className="mt-10">
      <a href="/#/" className="text-violet-600 font-bold">← Volver al inicio</a>
    </div>
  </div>
);

const App: React.FC = () => {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/servicios" element={<PlaceholderPage title="Nuestros Servicios" />} />
          <Route path="/servicios/:slug" element={<PlaceholderPage title="Detalle del Servicio" />} />
          <Route path="/soluciones" element={<PlaceholderPage title="Soluciones por Sector" />} />
          <Route path="/casos" element={<PlaceholderPage title="Casos y Demos" />} />
          <Route path="/proceso" element={<PlaceholderPage title="Nuestro Proceso" />} />
          <Route path="/sobre-nosotros" element={<PlaceholderPage title="Sobre Autometrix" />} />
          <Route path="/contacto" element={<PlaceholderPage title="Contacto" />} />
          <Route path="/auditoria-gratis" element={<Audit />} />
          <Route path="/agencia-ia-albacete" element={<LocalSEO />} />
          
          {/* Legal pages */}
          <Route path="/aviso-legal" element={<PlaceholderPage title="Aviso Legal" />} />
          <Route path="/politica-privacidad" element={<PlaceholderPage title="Política de Privacidad" />} />
          <Route path="/politica-cookies" element={<PlaceholderPage title="Política de Cookies" />} />
          <Route path="/accesibilidad" element={<PlaceholderPage title="Accesibilidad" />} />
        </Routes>
      </Layout>
    </Router>
  );
};

export default App;
