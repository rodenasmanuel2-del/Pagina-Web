
import React from 'react';
import { NavItem, Service, Sector, CaseStudy } from './types';

export const NAV_LINKS: NavItem[] = [
  { label: 'Servicios', path: '/servicios' },
  { label: 'Soluciones', path: '/soluciones' },
  { label: 'Casos/Demos', path: '/casos' },
  { label: 'Proceso', path: '/proceso' },
  { label: 'Nosotros', path: '/sobre-nosotros' },
  { label: 'Contacto', path: '/contacto' },
];

export const SERVICES: Service[] = [
  {
    id: 'n8n',
    slug: 'automatizacion-procesos-n8n',
    title: 'Automatización de Procesos con n8n',
    description: 'Conectamos tus herramientas favoritas para que el trabajo tedioso se haga solo.',
    icon: '⚡',
    problem: [
      'Entrada manual de datos repetitiva.',
      'Falta de sincronización entre herramientas (CRM, ERP, Google Sheets).',
      'Pérdida de tiempo en tareas administrativas de bajo valor.'
    ],
    solution: 'Implementamos flujos de trabajo autónomos con n8n que gestionan tus datos, envían notificaciones y actualizan tus sistemas sin intervención humana.',
    includes: [
      'Auditoría técnica de procesos actuales.',
      'Diseño de arquitectura de flujos en n8n.',
      'Integración con más de 400 aplicaciones.',
      'Soporte y mantenimiento reactivo.'
    ],
    steps: [
      'Mapeo de procesos.',
      'Desarrollo de nodos personalizados.',
      'Pruebas en entorno staging.',
      'Despliegue y monitorización.'
    ],
    results: [
      'Ahorro de hasta 20 horas semanales por empleado.',
      'Eliminación total de errores humanos.',
      'Respuesta inmediata a eventos de negocio.'
    ],
    stack: ['n8n', 'Python', 'Webhooks', 'REST APIs']
  },
  {
    id: 'ia-integration',
    slug: 'integracion-ia-empresas',
    title: 'Integración de IA en Empresas',
    description: 'Somos tu socio tecnológico de IA. Implementamos hoy, optimizamos siempre.',
    icon: '🧠',
    problem: [
      'Sensación de quedarse atrás frente a la competencia.',
      'Incapacidad para procesar grandes volúmenes de información.',
      'Falta de personalización en la atención a escala.'
    ],
    solution: 'Actuamos como consultores e implementadores de soluciones de IA (LLMs, Vision, Audio) adaptadas específicamente a tu modelo de negocio.',
    includes: [
      'Consultoría estratégica de IA.',
      'Desarrollo de micro-modelos personalizados.',
      'Capacitación de equipo interno.',
      'Optimización continua de prompts.'
    ],
    steps: [
      'Análisis de datos corporativos.',
      'Selección de modelos (Gemini, GPT-4, Llama).',
      'Integración vía API.',
      'Ajuste fino (Fine-tuning).'
    ],
    results: [
      'Toma de decisiones basada en datos asistida por IA.',
      'Nuevas capacidades de producto/servicio.',
      'Escalabilidad infinita operativa.'
    ],
    stack: ['Gemini API', 'LangChain', 'OpenAI', 'Pinecone']
  },
  {
    id: 'whatsapp',
    slug: 'chatbots-whatsapp-empresas',
    title: 'Chatbots WhatsApp para Empresas',
    description: 'Atención al cliente 24/7 en el canal que tus clientes ya usan.',
    icon: '💬',
    problem: [
      'Clientes que no reciben respuesta fuera de horario.',
      'Saturación de los canales de soporte.',
      'Pérdida de leads por lentitud en la respuesta.'
    ],
    solution: 'Creamos agentes conversacionales inteligentes en WhatsApp que resuelven dudas, agendan citas y califican leads automáticamente.',
    includes: [
      'Configuración de API oficial de WhatsApp.',
      'Entrenamiento de agente con base de conocimiento propia.',
      'Dashboard de control y analítica.',
      'Traspaso fluido a humano cuando es necesario.'
    ],
    steps: [
      'Definición de flujos conversacionales.',
      'Carga de base de conocimientos.',
      'Integración con CRM.',
      'Lanzamiento oficial.'
    ],
    results: [
      'Tasa de respuesta inmediata del 100%.',
      'Reducción del 70% en el volumen de tickets manuales.',
      'Aumento en la conversión de ventas por canal directo.'
    ],
    stack: ['Meta Cloud API', 'ManyChat', 'n8n', 'Gemini']
  },
  {
    id: 'voicebot',
    slug: 'chatbot-voz-empresas',
    title: 'Agentes de Voz con IA',
    description: 'Llamadas telefónicas humanas, inteligentes y escalables.',
    icon: '📞',
    problem: [
      'Centralitas colapsadas.',
      'Coste elevado de call centers externos.',
      'No-shows en citas por falta de confirmación telefónica.'
    ],
    solution: 'Desplegamos agentes de voz que pueden realizar y recibir llamadas con lenguaje natural para confirmar citas, encuestas o soporte básico.',
    includes: [
      'Clonación de voz profesional.',
      'Lógica de gestión de interrupciones.',
      'Integración con sistema de telefonía VoIP.',
      'Registro de transcripciones automático.'
    ],
    steps: [
      'Scripting conversacional de voz.',
      'Configuración de latencia baja.',
      'Integración con agenda/calendario.',
      'Testing de acento y tono.'
    ],
    results: [
      'Disminución drástica de citas perdidas.',
      'Atención multilingüe instantánea.',
      'Reducción de costes operativos telefónicos.'
    ],
    stack: ['Vapi', 'ElevenLabs', 'Gemini Live API', 'Twilio']
  }
];

export const SECTORS: Sector[] = [
  {
    id: 'clinicas',
    slug: 'ia-para-clinicas',
    title: 'Clínicas y Salud',
    description: 'Optimiza la agenda y mejora la experiencia del paciente.',
    pains: ['Cancelaciones de última hora', 'Gestión de expedientes', 'Soporte preventa'],
    solutions: ['Recordatorio de voz automático', 'Bot de triaje IA', 'Automatización de facturación']
  },
  {
    id: 'academias',
    slug: 'ia-para-academias',
    title: 'Academias y Centros de Formación',
    description: 'Escala tu enseñanza y automatiza las tareas administrativas.',
    pains: ['Dudas constantes de alumnos', 'Gestión de matrículas', 'Evaluación de exámenes'],
    solutions: ['Tutor IA 24/7', 'Automatización de pagos', 'Generación de material didáctico']
  }
];

export const CASE_STUDIES: CaseStudy[] = [
  {
    id: 'clinica-salak',
    slug: 'clinica-salak',
    client: 'Clínica Salak',
    context: 'Centro médico estético con alto volumen de llamadas.',
    problem: 'Perdían el 30% de las llamadas por estar atendiendo pacientes en local.',
    solution: 'Implementación de agente de voz IA que gestiona citas y resuelve dudas frecuentes.',
    results: 'Recuperación del 95% de los leads telefónicos y agenda llena con 2 semanas de antelación.'
  }
];
