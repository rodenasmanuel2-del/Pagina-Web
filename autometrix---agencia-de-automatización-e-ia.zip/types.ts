
export interface NavItem {
  label: string;
  path: string;
}

export interface Service {
  id: string;
  slug: string;
  title: string;
  description: string;
  icon: string;
  problem: string[];
  solution: string;
  includes: string[];
  steps: string[];
  results: string[];
  stack: string[];
}

export interface Sector {
  id: string;
  slug: string;
  title: string;
  description: string;
  pains: string[];
  solutions: string[];
}

export interface CaseStudy {
  id: string;
  slug: string;
  client: string;
  context: string;
  problem: string;
  solution: string;
  results: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}
